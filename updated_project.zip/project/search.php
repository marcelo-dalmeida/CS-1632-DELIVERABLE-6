<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Search</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div id="page-wrapper">
			<?php session_start(); ?>
		
			<!-- Header -->
				<header id="header">
					<h1 id="logo">
					<?php 
						if (array_key_exists('user_name', $_SESSION))
						{
							echo 'Hey, '.$_SESSION['user_name'].'. ';
						}
					?></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="insert.php">Insert</a></li>';
								
								}
							?>
							<li><a href="search.php">Search</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="delete.php">Delete</a></li>';
									echo '<li><a href="./php/login.php">Manager</a></li>';
								}
								else
								{
									echo '<li><a href="about.html">About</a></li>';
								}
							?>
							<li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<a href="./php/login.php?logout" class="button special">Log out</a>';
								}
								else
								{
									echo '<a href="./php/login.php" class="button special">Log in</a>';
								}
							?>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
							<h2> Search for a car </h2>
							
							
						</header>

						<!-- Content -->
						<center>
							<form action="./php/search_result.php" method="post" name="search_form" method="post">
								
								<div class="6u$ 12u$(xsmall)">
								
									<input type=text name="license_plate" placeholder="License Plate"><br>
									
									<div class="select-wrapper">
										<select name="manufacturer_logical">
											<option value=" AND ">Select and/or only to include another criteria</option>
											<option value=" AND ">and</option>
											<option value=" OR ">or</option>
										</select>
										</div>
									<input type=text name="manufacturer"  placeholder="Manufacturer"><br>
									
									<div class="select-wrapper">
										<select name="model_logical">
											<option value=" AND ">Select and/or only to include another criteria</option>
											<option value=" AND ">and</option>
											<option value=" OR ">or</option>
										</select>
									</div>
									<input type=text name="model" placeholder="Model"><br>
									
									<div class="select-wrapper">
										<select name="year_logical">
											<option value=" AND ">Select and/or only to include another criteria</option>
											<option value=" AND ">and</option>
											<option value=" OR ">or</option>
										</select>
									</div>
									<input type=number min="1800" name="year"  placeholder="Year">
									<div class="select-wrapper">
										<select name="year_comparative">
											<option value="=">Results equals selected year</option>
											<option value=">">Results greater than selected year</option>
											<option value=">=">Results greater or equal than selected year</option>
											<option value="<">Results less than selected year</option>
											<option value="<=">Results less or equal than selected year</option>
										</select><br>
									</div>
									
									<div class="select-wrapper">
										<select name="mileage_logical">
											<option value=" AND ">Select and/or only to include another criteria</option>
											<option value=" AND ">and</option>
											<option value=" OR ">or</option>
										</select>
									</div>
									<input type=number min="0" name="mileage"  placeholder="Mileage">
									<div class="select-wrapper">
										<select name="mileage_comparative">
											<option value="=">Results equals selected year</option>
											<option value=">">Results greater than selected year</option>
											<option value=">=">Results greater or equal than selected year</option>
											<option value="<">Results less than selected year</option>
											<option value="<=">Results less or equal than selected year</option>
										</select><br>
									</div>
									
									<div class="select-wrapper">
										<select name="color_logical">
											<option value=" AND ">and/or</option>
											<option value=" AND ">and</option>
											<option value=" OR ">or</option>
										</select>
									</div>
									<input type=text name="color" placeholder="Color"><br>
									
									<div class="select-wrapper">
										<select name="price_logical">
											<option value=" AND ">Select and/or only to include another criteria</option>
											<option value=" AND ">and</option>
											<option value=" OR ">or</option>
										</select>
									</div>
									<input type=number min="0" step="0.01" name="price" placeholder="Price">
									<div class="select-wrapper">
										<select name="price_comparative">
											<option value="=">Results equals selected price</option>
											<option value=">">Results greater than selected price</option>
											<option value=">=">Results greater or equal than selected price</option>
											<option value="<">Results less than selected price</option>
											<option value="<=">Results less or equal than selected price</option>
										</select><br>
									</div>
								</div>
								
								<br>
								<input type=submit name="search_button" value="Search" class="special button" onClick="(search_form.license_plate.value, search_form.manufacturer.value, search_form.model.value,
								search_form.year.value, search_form.color.value, search_form.price.value,
								search_form.manufacturer_logical.value, search_form.model_logical.value, search_form.year_logical.value, search_form.color_logical.value, search_form.price_logical.value,
								search_form.year_comparative.value, search_form.price_comparative.value)"><br><br>
							</form>
						
						</center>

					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon alt fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>
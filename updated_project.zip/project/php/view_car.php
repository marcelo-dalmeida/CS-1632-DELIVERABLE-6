<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Selected car</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="./../assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		
		<script language="JavaScript">
			function calculate_payment(price_with_taxes, downpayment, year, interest){
			
				var price_with_taxes = parseFloat(price_with_taxes)
				var downpayment = parseFloat(downpayment)
				var year = parseInt(year)
				var interest = parseInt(interest)
			
			
				var total_installment
				var n_of_months
				var total_price_per_month
				var total_price
				
				if (downpayment > price_with_taxes || downpayment < 0){
					downpayment = 0
				}
				
				if (year > 0 && year <= 5)
				{
					total_installment = (price_with_taxes - downpayment)*(1+(interest/100))
					n_of_months = year * 12
				}
				else
				{
					total_installment = (price_with_taxes - downpayment)
					n_of_months = 1
				}
				
				
				total_price = downpayment + total_installment
				total_price_per_month = total_installment / n_of_months
				
				document.getElementById('total_downpayment').value = downpayment.toFixed(2)
				document.getElementById('total_price_per_month').value = total_price_per_month.toFixed(2)
				document.getElementById('n_of_months').value = n_of_months
				document.getElementById('total_price').value = total_price.toFixed(2)
			}
			
			
		</script>
		
	</head>
	<body>
		<div id="page-wrapper">
		
			<?php session_start(); ?>
			<!-- Header -->
				<header id="header">
					<h1 id="logo">
					<?php 
						if (array_key_exists('user_name', $_SESSION))
						{
							echo 'Hey, '.$_SESSION['user_name'].'. ';
						}
					?></h1>
					<nav id="nav">
						<ul>
							<li><a href="./../index.php">Home</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../insert.php">Insert</a></li>';
								
								}
							?>
							<li><a href="./../search.php">Search</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../delete.php">Delete</a></li>';
									echo '<li><a href="login.php">Manager</a></li>';
								}
								else
								{
									echo '<li><a href="./../about.html">About</a></li>';
								}
							?>
							<li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<a href="login.php?logout" class="button special">Log out</a>';
								}
								else
								{
									echo '<a href="login.php" class="button special">Log in</a>';
								}
							?>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
							<h2>Calculate payment</h2>
							
						</header>

						<!-- Content -->
						<center>
							<?php
								$license_plate = $_REQUEST['license_plate'];

								$conn = mysql_connect("localhost", "client", "client");
								mysql_select_db("project", $conn);
								
								$sql = "SELECT * FROM car WHERE license_plate = '$license_plate';";
								
								$result = mysql_query($sql, $conn);
								
								$field = mysql_fetch_field($result);
								$row = mysql_fetch_assoc($result);
								
								//get row data as an associative array
								print "<table>";
								
								print "<tr>\n";
								$i = 0;
								while ($i < mysql_num_fields($result)-1) {
									$field = mysql_fetch_field($result, $i);
									echo "<td>".$field->name."</td>";
									$i++;
								}
								print "</tr>";
								
								
								print "<tr>";
								print "<td>".$row['license_plate']."</td>";
								print "<td>".$row['manufacturer']."</td>";
								print "<td>".$row['model']."</td>";
								print "<td>".$row['year']."</td>";
								print "<td>".$row['mileage']."</td>";
								print "<td>".$row['color']."</td>";
								print "<td>".$row['price']."</td>";
								print "</tr>";
								print "</table>";
								
								print "<img src=./../pictures/".$row['picture_name']." width=480 height=320><br>";
								
							 ?>

							The car's photo is merely illustrative, it doesn't reflect the product. <br><br>

							 <form name='payment_form' method='post'>
								<div class="6u$ 12u$(xsmall)">
									<!--price of the car (price + , 5-year payment, downpayment, taxes - 7%) (interest/year)-->
									<h4>Car price (no taxes):</h4>
									<input type=number name="price" value="<?php echo floatval($row['price']); ?>" readonly><br>
									
									<h4>State taxes (%):</h4>
									<input type=number name="tax" value="7" readonly><br>
									
									<h4>Car price (taxes included):</h4>
									<input type=number name="price_with_taxes" value="<?php echo floatval($row['price'])*1.07; ?>" readonly><br>
									
									<h4>Downpayment:</h4>
									<input type=number name="downpayment" step=0.01 value=0 min=0 max="<?php echo floatval($row['price'])*1.07; ?>" ><br>
									
									<h4>#-year payment:</h4>
									<input type=number name="year" value=0  min=0 max=5><br>
									
									<h4>Interest/year (%):</h4>
									<input type=number name="interest" value="9" readonly><br><br>
									
									<input type=button name='calculate_payment_button' value='Calculate payment' class="special button" onClick='calculate_payment(payment_form.price_with_taxes.value, payment_form.downpayment.value,
									payment_form.year.value, payment_form.interest.value)'><br><br>
									
									
									<h4>Downpayment:</h4>
									<input type=number id="total_downpayment" readonly><br>
									
									<h4>Cost/Month:</h4>
									<input type=number id="total_price_per_month" readonly><br>
									
									<h4>Number of months:</h4>
									<input type=number id="n_of_months" readonly><br>
									
									<h4>Total price:</h4>
									<input type=number id="total_price" readonly><br>
								</div>
						</center>

					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon alt fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="./../assets/js/jquery.min.js"></script>
			<script src="./../assets/js/jquery.scrolly.min.js"></script>
			<script src="./../assets/js/jquery.dropotron.min.js"></script>
			<script src="./../assets/js/jquery.scrollex.min.js"></script>
			<script src="./../assets/js/skel.min.js"></script>
			<script src="./../assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="./../assets/js/main.js"></script>

	</body>
</html>
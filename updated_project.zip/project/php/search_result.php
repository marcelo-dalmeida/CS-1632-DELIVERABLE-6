<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Search</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="./../assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div id="page-wrapper">
		
			<?php session_start(); ?>
			<!-- Header -->
				<header id="header">
					<h1 id="logo">
					<?php 
						if (array_key_exists('user_name', $_SESSION))
						{
							echo 'Hey, '.$_SESSION['user_name'].'. ';
						}
					?></h1>
					<nav id="nav">
						<ul>
							<li><a href="./../index.php">Home</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../insert.php">Insert</a></li>';
								
								}
							?>
							<li><a href="./../search.php">Search</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../delete.php">Delete</a></li>';
									echo '<li><a href="login.php">Manager</a></li>';
								}
								else
								{
									echo '<li><a href="./../about.html">About</a></li>';
								}
							?>
							<li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<a href="login.php?logout" class="button special">Log out</a>';
								}
								else
								{
									echo '<a href="login.php" class="button special">Log in</a>';
								}
							?>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
							<h2>Select an available car</h2>
							

						</header>

						<!-- Content -->
						<center>
							<?php
								$license_plate = $_REQUEST['license_plate'];
								$manufacturer = $_REQUEST['manufacturer'];
								$model = $_REQUEST['model'];
								$year = $_REQUEST['year'];
								$mileage = $_REQUEST['mileage'];
								$color = $_REQUEST['color'];
								$price = $_REQUEST['price'];
								
								$manufacturer_logical = $_REQUEST['manufacturer_logical'];
								$model_logical = $_REQUEST['model_logical'];
								$year_logical = $_REQUEST['year_logical'];
								$mileage_logical = $_REQUEST['mileage_logical'];
								$color_logical = $_REQUEST['color_logical'];
								$price_logical = $_REQUEST['price_logical'];
								
								$year_comparative = $_REQUEST['year_comparative'];
								$price_comparative = $_REQUEST['price_comparative'];
								
								$conn = mysql_connect("localhost", "client", "client");
								mysql_select_db("project", $conn);
								
								$sql = "SELECT license_plate, manufacturer, model, year, mileage, color, price FROM car ";
								$sql_parameters = "";
								
								$search_field_count = 0;
								
								if ($license_plate != "")
								{	
									if ($search_field_count == 0)
									{
										$sql = $sql . "WHERE ";
									}

									$search_field_count = $search_field_count + 1;
								
									$sql_parameters = $sql_parameters . "license_plate = '$license_plate'";
									
								}
								
								if ($manufacturer != "")
								{
									if ($search_field_count == 0)
									{
										$sql = $sql . "WHERE ";
									}
									else
									{
										$sql_parameters = $sql_parameters . $manufacturer_logical;
									}
									
									$search_field_count = $search_field_count + 1;
									
									$sql_parameters = $sql_parameters . "manufacturer = '$manufacturer'";
								}
								
								if ($model != "")
								{
									if ($search_field_count == 0)
									{
										$sql = $sql . "WHERE ";
									}
									else
									{
										$sql_parameters = $sql_parameters . $model_logical;
									}
									
									$search_field_count = $search_field_count + 1;
									
									$sql_parameters = $sql_parameters . "model = '$model'";
								}
								
								if ($year != "")
								{
									if ($search_field_count == 0)
									{
										$sql = $sql . "WHERE ";
									}
									else
									{
										$sql_parameters = $sql_parameters . $year_logical;
									}
									
									$search_field_count = $search_field_count + 1;
									
									$sql_parameters = $sql_parameters . "year $year_comparative '$year'";
								}
								
								if ($mileage != "")
								{
									if ($search_field_count == 0)
									{
										$sql = $sql . "WHERE ";
									}
									else
									{
										$sql_parameters = $sql_parameters . $mileage_logical;
									}
									
									$search_field_count = $search_field_count + 1;
									
									$sql_parameters = $sql_parameters . "mileage $mileage_comparative '$mileage'";
								}
								
								if ($color != "")
								{
									if ($search_field_count == 0)
									{
										$sql = $sql . "WHERE ";
									}
									else
									{
										$sql_parameters = $sql_parameters . $color_logical;
									}
									
									$search_field_count = $search_field_count + 1;
									
									$sql_parameters = $sql_parameters . "color = '$color'";
								}
								
								if ($price != "")
								{
									if ($search_field_count == 0)
									{
										$sql = $sql . "WHERE ";
									}
									else
									{
										$sql_parameters = $sql_parameters . $price_logical;
									}
									
									$search_field_count = $search_field_count + 1;
									
									$sql_parameters = $sql_parameters . "price $price_comparative '$price'";
								}
								
								echo $sql_parameters;
								
								$sql = $sql . $sql_parameters . ";";

								
								
								
								$result = mysql_query($sql, $conn);
								
								print "<table border = 1>\n";

								if (mysql_num_rows($result)==0)
								{
									echo "<br> There is no car with this criteria.";
								}
								else
								{
									//get field names
									print "<tr>\n";
									while ($field = mysql_fetch_field($result)){
									print " <td><h4>$field->name</h4></td>\n";
									} // end while
									print " <td></td>\n";
									print "</tr>\n\n";
									
									
									//get row data as an associative array
									while ($row = mysql_fetch_assoc($result)){
										print "<tr>\n";
										//look at each field
										foreach ($row as $col=>$val){
											print " <td>$val</td>\n";
										} // end foreach
										print 
										"<td>
											<form action='view_car.php' method='post' name='view_car_form' method='post'>
												<input type=hidden name='license_plate' value=".$row['license_plate'].">
												<input type=submit name='view_car_button' id='view_car_button'  value='view car' onClick='(view_car_form.license_plate.value)'>
											</form>
										</td>\n";
										print "</tr>\n\n";
									}// end while

									print "</table>\n";
								}

							 ?>
						</center>

					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon alt fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="./../assets/js/jquery.min.js"></script>
			<script src="./../assets/js/jquery.scrolly.min.js"></script>
			<script src="./../assets/js/jquery.dropotron.min.js"></script>
			<script src="./../assets/js/jquery.scrollex.min.js"></script>
			<script src="./../assets/js/skel.min.js"></script>
			<script src="./../assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="./../assets/js/main.js"></script>

	</body>
</html>
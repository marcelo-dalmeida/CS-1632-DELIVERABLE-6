<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Insert</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="./../assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div id="page-wrapper">
		
			<?php session_start(); ?>
			<!-- Header -->
				<header id="header">
					<h1 id="logo">
					<?php 
						if (array_key_exists('user_name', $_SESSION))
						{
							echo 'Hey, '.$_SESSION['user_name'].'. ';
						}
					?></h1>
					<nav id="nav">
						<ul>
							<li><a href="./../index.php">Home</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../insert.php">Insert</a></li>';
								
								}
							?>
							<li><a href="./../search.php">Search</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../delete.php">Delete</a></li>';
									echo '<li><a href="login.php">Manager</a></li>';
								}
								else
								{
									echo '<li><a href="./../about.html">About</a></li>';
								}
							?>
							<li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<a href="login.php?logout" class="button special">Log out</a>';
								}
								else
								{
									echo '<a href="login.php" class="button special">Log in</a>';
								}
							?>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
							<h2>
								<?php
									$license_plate = $_REQUEST['license_plate'];
									$manufacturer = $_REQUEST['manufacturer'];
									$model = $_REQUEST['model'];
									$year = $_REQUEST['year'];
									$mileage = $_REQUEST['mileage'];
									$color = $_REQUEST['color'];
									$price = $_REQUEST['price'];
									
									$picture_name = strtolower($manufacturer) . " " . strtolower($model) . ".jpg";
									$picture_name = str_replace(' ', '_', $picture_name);

									$conn = mysql_connect("localhost", "root", "");
									mysql_select_db("project", $conn);
									
									$sql = "INSERT INTO car (license_plate, manufacturer, model, year, mileage, color, price, picture_name) 
									VALUES ('$license_plate', '$manufacturer', '$model', '$year', '$mileage', '$color', '$price', '$picture_name');";
									$result = mysql_query($sql, $conn);

									if ($result == 1){
										echo "Inserted with success!<br>";
									}
									else {
										echo "There is already a car with this license plate<br>";
									}
										
									
								?>
							</h2>
						</header>

						<!-- Content -->

					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon alt fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="./../assets/js/jquery.min.js"></script>
			<script src="./../assets/js/jquery.scrolly.min.js"></script>
			<script src="./../assets/js/jquery.dropotron.min.js"></script>
			<script src="./../assets/js/jquery.scrollex.min.js"></script>
			<script src="./../assets/js/skel.min.js"></script>
			<script src="./../assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="./../assets/js/main.js"></script>

	</body>
</html>
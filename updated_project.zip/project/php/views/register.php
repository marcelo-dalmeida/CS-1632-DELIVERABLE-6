<!DOCTYPE html PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN' 'http://www.w3.org/TR/html4/loose.dtd'>
<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>

<title>table layout</title>

</head>
<body>


<?php
// show potential errors / feedback (from registration object)
if (isset($registration)) {
    if ($registration->errors) {
        foreach ($registration->errors as $error) {
            echo $error;
        }
    }
    if ($registration->messages) {
        foreach ($registration->messages as $message) {
            echo $message;
        }
    }
}
?>

<!-- register form -->
<form method="post" action="register.php" name="registerform">

	<div class="6u$ 12u$(xsmall)">
		<!-- the user name input field uses a HTML5 pattern check -->
		
		<input id="login_input_username" class="login_input" type="text" pattern="[a-zA-Z0-9]{2,64}" name="user_name" placeholder="Username (only letters and numbers, 2 to 64 characters)"		required /><br>

		<!-- the email input field uses a HTML5 email type check -->
		<input id="login_input_email" class="login_input" type="email" name="user_email" placeholder="Email" required /><br>

		<input id="login_input_password_new" class="login_input" type="password" name="user_password_new" pattern=".{6,}" placeholder="Password (min. 6 characters)" required autocomplete="off"/><br>
		
		<input id="login_input_password_repeat" class="login_input" type="password" name="user_password_repeat" pattern=".{6,}" placeholder="Repeat Password" required autocomplete="off" /><br><br>
		<input type="submit"  name="register" class="special button" value="Register" />
	</div>
</form>

<br/>
</body></html>
<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Login</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="./../assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div id="page-wrapper">
			<?php
			/**
			 * A simple, clean and secure PHP Login Script / MINIMAL VERSION
			 * For more versions (one-file, advanced, framework-like) visit http://www.php-login.net
			 *
			 * Uses PHP SESSIONS, modern password-hashing and salting and gives the basic functions a proper login system needs.
			 *
			 * @author Panique
			 * @link https://github.com/panique/php-login-minimal/
			 * @license http://opensource.org/licenses/MIT MIT License
			 */

			// checking for minimum PHP version
			if (version_compare(PHP_VERSION, '5.3.7', '<')) {
				exit("Sorry, Simple PHP Login does not run on a PHP version smaller than 5.3.7 !");
			} else if (version_compare(PHP_VERSION, '5.5.0', '<')) {
				// if you are using PHP 5.3 or PHP 5.4 you have to include the password_api_compatibility_library.php
				// (this library adds the PHP 5.5 password hashing functions to older versions of PHP)
				require_once("libraries/password_compatibility_library.php");
			}

			// include the configs / constants for the database connection
			require_once("config/db.php");

			// load the login class
			require_once("classes/Login.php");

			// create a login object. when this object is created, it will do all login/logout stuff automatically
			// so this single line handles the entire login process. in consequence, you can simply ...
			$login = new Login();
			?>
		
			<!-- Header -->
				<header id="header">
					<h1 id="logo">
					<?php 
						if (array_key_exists('user_name', $_SESSION))
						{
							echo 'Hey, '.$_SESSION['user_name'].'. ';
						}
					?></h1>
					<nav id="nav">
						<ul>
							<li><a href="./../index.php">Home</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../insert.php">Insert</a></li>';
								
								}
							?>
							<li><a href="./../search.php">Search</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="./../delete.php">Delete</a></li>';
									echo '<li><a href="login.php">Manager</a></li>';
								}
								else
								{
									echo '<li><a href="./../about.html">About</a></li>';
								}
							?>
							<li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<a href="login.php?logout" class="button special">Log out</a>';
								}
								else
								{
									echo '<a href="login.php" class="button special">Log in</a>';
								}
							?>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
					
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo "<h2>".$_SESSION['user_name']."</h2>";
								}
								else
								{
									echo "<h2> Hi, manager. Login now!</h2>";
								}
							?>

						</header>

						<!-- Content -->
						
							
							<center>
							<?php

							// ... ask if we are logged in here:
							if ($login->isUserLoggedIn() == true) {
								// the user is logged in. you can do whatever you want here.
								// for demonstration purposes, we simply show the "you are logged in" view.
								print "
								<!-- if you need user information, just put them into the $ _SESSION variable and output them here -->
								
								<p>Hey, ".$_SESSION['user_name'] .". You are logged in.
								Try to close this browser tab and open it again. Still logged in! ;)</p>

								<a href='register.php' class='button special'>Register new account</a><br><br>
								";

							} else {
								// the user is not logged in. you can do whatever you want here.
								// for demonstration purposes, we simply show the "you are not logged in" view.
								
								// show potential errors / feedback (from login object)
								if (isset($login)) {
									if ($login->errors) {
										foreach ($login->errors as $error) {
											echo $error;
										}
									}
									if ($login->messages) {
										foreach ($login->messages as $message) {
											echo $message;
										}
									}
								}
								
								print "
								<!-- login form box -->
									<!-- Form -->
									
									<script>    
										if(typeof window.history.pushState == 'function') {
											window.history.pushState({}, 'Hide', 'http://localhost/project/php/login.php');
										}
									</script>
									
									<section>
										<form method='post' 'login.php?login' name='loginform'>
											
											<div class='6u 12u$(xsmall)'>
												<input type='text' name='user_name' id='login_input_username' value='' placeholder='Username' class='login_input' required />
											</div>
											<div class='6u$ 12u$(xsmall)'>
												<input type='password' name='user_password' id='login_input_password' value='' placeholder='Password' class='login_input' autocomplete='off' required />
											</div><br><br>
											
											<ul class='actions'>
												<li><input type='submit' name='login' value='Log In' class='special' /></li>
											</ul>
										</form>
									</section>
								";
							}?>
							</center>

					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon alt fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="./../assets/js/jquery.min.js"></script>
			<script src="./../assets/js/jquery.scrolly.min.js"></script>
			<script src="./../assets/js/jquery.dropotron.min.js"></script>
			<script src="./../assets/js/jquery.scrollex.min.js"></script>
			<script src="./../assets/js/skel.min.js"></script>
			<script src="./../assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="./../assets/js/main.js"></script>

	</body>
</html>
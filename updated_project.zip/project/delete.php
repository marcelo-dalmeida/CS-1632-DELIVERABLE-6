<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Delete</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div id="page-wrapper">
			<?php session_start(); ?>
		
			<!-- Header -->
				<header id="header">
					<h1 id="logo">
					<?php 
						if (array_key_exists('user_name', $_SESSION))
						{
							echo 'Hey, '.$_SESSION['user_name'].'. ';
						}
					?></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="insert.php">Insert</a></li>';
								
								}
							?>
							<li><a href="search.php">Search</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="delete.php">Delete</a></li>';
									echo '<li><a href="./php/login.php">Manager</a></li>';
								}
								else
								{
									echo '<li><a href="about.html">About</a></li>';
								}
							?>
							<li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<a href="./php/login.php?logout" class="button special">Log out</a>';
								}
								else
								{
									echo '<a href="./php/login.php" class="button special">Log in</a>';
								}
							?>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Main -->
				<div id="main" class="wrapper style1">
					<div class="container">
						<header class="major">
							<h2> Delete a car </h2>
							
							
						</header>

						<!-- Content -->
						<center>
							<form action="./php/delete_result.php" method="post" name="delete_form" method="post">
								<div class="6u$ 12u$(xsmall)">
									<input type=text name="license_plate" placeholder="License Plate"><br>
								</div>

								<br>
								<input type=submit name="delete_button" value="Delete" class="special button" onClick="(delete_form.license_plate.value)"><br><br>
							</form>
						
						</center>

					</div>
				</div>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon alt fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>
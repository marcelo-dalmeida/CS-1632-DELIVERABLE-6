<!DOCTYPE HTML>
<!--
	Landed by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Home</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body class="landing">
		<div id="page-wrapper">
			
			<?php session_start(); ?>
			<!-- Header -->
				<header id="header">
					<h1 id="logo">
					<?php 
						if (array_key_exists('user_name', $_SESSION))
						{
							echo 'Hey, '.$_SESSION['user_name'].'. ';
						}
					?></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="insert.php">Insert</a></li>';
								
								}
							?>
							<li><a href="search.php">Search</a></li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<li><a href="delete.php">Delete</a></li>';
									echo '<li><a href="./php/login.php">Manager</a></li>';
								}
								else
								{
									echo '<li><a href="about.html">About</a></li>';
								}
							?>
							<li>
							<?php 
								if (array_key_exists('user_name', $_SESSION))
								{
									echo '<a href="./php/login.php?logout" class="button special">Log out</a>';
								}
								else
								{
									echo '<a href="./php/login.php" class="button special">Log in</a>';
								}
							?>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">
					<div class="content">
						<header>
							<h2>The future has landed</h2>
							<p>And the best online car store is here.<br />
							You're welcome.</p>
						</header>
						<span class="image"><img src="images/pic01.jpg" alt="" /></span>
					</div>
					<a href="#one" class="goto-next scrolly">Next</a>
				</section>


			<!-- One -->
				<section id="one" class="wrapper style1 special fade-up">
					<div class="container">
						<header class="major">
							<h2>See why we have the best online car store of the UNIVERSE</h2>
							<p>With all modesty, of course</p>
						</header>
						<div class="box alt">
							<div class="row uniform">
								<section class="4u 6u(medium) 12u$(xsmall)">
									<span class="icon alt major fa-area-chart"></span>
									<h3>Fiery</h3>
									<p>We keep growing fast. We have a dream</p>
								</section>
								<section class="4u 6u$(medium) 12u$(xsmall)">
									<span class="icon alt major fa-comment"></span>
									<h3>Customer's favorite</h3>
									<p>The users' best recommendation</p>
								</section>
								<section class="4u$ 6u(medium) 12u$(xsmall)">
									<span class="icon alt major fa-flask"></span>
									<h3>Building upon Business Intelligence</h3>
									<p>We research continually better ways to deliver to you the best experience</p>
								</section>
								<section class="4u 6u$(medium) 12u$(xsmall)">
									<span class="icon alt major fa-paper-plane"></span>
									<h3>We aim high</h3>
									<p>We are committed to build the best online car store</p>
								</section>
								<section class="4u 6u(medium) 12u$(xsmall)">
									<span class="icon alt major fa-file"></span>
									<h3>Fine selection</h3>
									<p>We have thousands of opportunities to your new car</p>
								</section>
								<section class="4u$ 6u$(medium) 12u$(xsmall)">
									<span class="icon alt major fa-lock"></span>
									<h3>Safe</h3>
									<p>We work hard to maintain your safety</p>
								</section>
							</div>
						</div>
					</div>
				</section>


			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon alt fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
						<li><a href="#" class="icon alt fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>